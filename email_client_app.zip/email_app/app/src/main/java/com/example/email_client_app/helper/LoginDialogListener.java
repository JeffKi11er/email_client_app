package com.example.email_client_app.helper;

public interface LoginDialogListener {
    void applyText(String email, String passwords);
}
