package com.example.email_client_app.helper;

public interface ItemListener {
    void onClick(int position);
    void onLongClick(int position);
}
